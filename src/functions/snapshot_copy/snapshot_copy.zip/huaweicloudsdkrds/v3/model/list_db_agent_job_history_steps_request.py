# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListDbAgentJobHistoryStepsRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'x_language': 'str',
        'instance_id': 'str',
        'history_id': 'str',
        'offset': 'int',
        'limit': 'int'
    }

    attribute_map = {
        'x_language': 'X-Language',
        'instance_id': 'instance_id',
        'history_id': 'history_id',
        'offset': 'offset',
        'limit': 'limit'
    }

    def __init__(self, x_language=None, instance_id=None, history_id=None, offset=None, limit=None):
        r"""ListDbAgentJobHistoryStepsRequest

        The model defined in huaweicloud sdk

        :param x_language: 语言。默认en-us。
        :type x_language: str
        :param instance_id: 实例ID
        :type instance_id: str
        :param history_id: 作业执行历史ID
        :type history_id: str
        :param offset: 索引位置，偏移量。从第一条数据偏移offset条数据后开始查询，默认为0（偏移0条数据，表示从第一条数据开始查询），必须为数字，不能为负数。
        :type offset: int
        :param limit: 查询记录数。默认为10，不能为负数，最小值为1，最大值为100。
        :type limit: int
        """
        
        

        self._x_language = None
        self._instance_id = None
        self._history_id = None
        self._offset = None
        self._limit = None
        self.discriminator = None

        if x_language is not None:
            self.x_language = x_language
        self.instance_id = instance_id
        self.history_id = history_id
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit

    @property
    def x_language(self):
        r"""Gets the x_language of this ListDbAgentJobHistoryStepsRequest.

        语言。默认en-us。

        :return: The x_language of this ListDbAgentJobHistoryStepsRequest.
        :rtype: str
        """
        return self._x_language

    @x_language.setter
    def x_language(self, x_language):
        r"""Sets the x_language of this ListDbAgentJobHistoryStepsRequest.

        语言。默认en-us。

        :param x_language: The x_language of this ListDbAgentJobHistoryStepsRequest.
        :type x_language: str
        """
        self._x_language = x_language

    @property
    def instance_id(self):
        r"""Gets the instance_id of this ListDbAgentJobHistoryStepsRequest.

        实例ID

        :return: The instance_id of this ListDbAgentJobHistoryStepsRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this ListDbAgentJobHistoryStepsRequest.

        实例ID

        :param instance_id: The instance_id of this ListDbAgentJobHistoryStepsRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def history_id(self):
        r"""Gets the history_id of this ListDbAgentJobHistoryStepsRequest.

        作业执行历史ID

        :return: The history_id of this ListDbAgentJobHistoryStepsRequest.
        :rtype: str
        """
        return self._history_id

    @history_id.setter
    def history_id(self, history_id):
        r"""Sets the history_id of this ListDbAgentJobHistoryStepsRequest.

        作业执行历史ID

        :param history_id: The history_id of this ListDbAgentJobHistoryStepsRequest.
        :type history_id: str
        """
        self._history_id = history_id

    @property
    def offset(self):
        r"""Gets the offset of this ListDbAgentJobHistoryStepsRequest.

        索引位置，偏移量。从第一条数据偏移offset条数据后开始查询，默认为0（偏移0条数据，表示从第一条数据开始查询），必须为数字，不能为负数。

        :return: The offset of this ListDbAgentJobHistoryStepsRequest.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListDbAgentJobHistoryStepsRequest.

        索引位置，偏移量。从第一条数据偏移offset条数据后开始查询，默认为0（偏移0条数据，表示从第一条数据开始查询），必须为数字，不能为负数。

        :param offset: The offset of this ListDbAgentJobHistoryStepsRequest.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ListDbAgentJobHistoryStepsRequest.

        查询记录数。默认为10，不能为负数，最小值为1，最大值为100。

        :return: The limit of this ListDbAgentJobHistoryStepsRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListDbAgentJobHistoryStepsRequest.

        查询记录数。默认为10，不能为负数，最小值为1，最大值为100。

        :param limit: The limit of this ListDbAgentJobHistoryStepsRequest.
        :type limit: int
        """
        self._limit = limit

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListDbAgentJobHistoryStepsRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
