# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateRebuildSlaveResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'workflow_id': 'str'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'workflow_id': 'workflow_id'
    }

    def __init__(self, instance_id=None, workflow_id=None):
        r"""CreateRebuildSlaveResponse

        The model defined in huaweicloud sdk

        :param instance_id: **参数解释**：  实例ID  **约束限制**：  不涉及。  **取值范围**：  不涉及。  **默认取值**：  不涉及。
        :type instance_id: str
        :param workflow_id: **参数解释**：  任务流ID  **约束限制**：  不涉及。  **取值范围**：  不涉及。  **默认取值**：  不涉及。
        :type workflow_id: str
        """
        
        super().__init__()

        self._instance_id = None
        self._workflow_id = None
        self.discriminator = None

        if instance_id is not None:
            self.instance_id = instance_id
        if workflow_id is not None:
            self.workflow_id = workflow_id

    @property
    def instance_id(self):
        r"""Gets the instance_id of this CreateRebuildSlaveResponse.

        **参数解释**：  实例ID  **约束限制**：  不涉及。  **取值范围**：  不涉及。  **默认取值**：  不涉及。

        :return: The instance_id of this CreateRebuildSlaveResponse.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this CreateRebuildSlaveResponse.

        **参数解释**：  实例ID  **约束限制**：  不涉及。  **取值范围**：  不涉及。  **默认取值**：  不涉及。

        :param instance_id: The instance_id of this CreateRebuildSlaveResponse.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def workflow_id(self):
        r"""Gets the workflow_id of this CreateRebuildSlaveResponse.

        **参数解释**：  任务流ID  **约束限制**：  不涉及。  **取值范围**：  不涉及。  **默认取值**：  不涉及。

        :return: The workflow_id of this CreateRebuildSlaveResponse.
        :rtype: str
        """
        return self._workflow_id

    @workflow_id.setter
    def workflow_id(self, workflow_id):
        r"""Sets the workflow_id of this CreateRebuildSlaveResponse.

        **参数解释**：  任务流ID  **约束限制**：  不涉及。  **取值范围**：  不涉及。  **默认取值**：  不涉及。

        :param workflow_id: The workflow_id of this CreateRebuildSlaveResponse.
        :type workflow_id: str
        """
        self._workflow_id = workflow_id

    def to_dict(self):
        import warnings
        warnings.warn("CreateRebuildSlaveResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateRebuildSlaveResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
