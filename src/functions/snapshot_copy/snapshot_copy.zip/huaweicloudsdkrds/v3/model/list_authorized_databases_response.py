# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListAuthorizedDatabasesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'databases': 'list[DatabaseWithPrivilege]',
        'total_count': 'int'
    }

    attribute_map = {
        'databases': 'databases',
        'total_count': 'total_count'
    }

    def __init__(self, databases=None, total_count=None):
        r"""ListAuthorizedDatabasesResponse

        The model defined in huaweicloud sdk

        :param databases: 数据库及相关权限。
        :type databases: list[:class:`huaweicloudsdkrds.v3.DatabaseWithPrivilege`]
        :param total_count: 总数。
        :type total_count: int
        """
        
        super().__init__()

        self._databases = None
        self._total_count = None
        self.discriminator = None

        if databases is not None:
            self.databases = databases
        if total_count is not None:
            self.total_count = total_count

    @property
    def databases(self):
        r"""Gets the databases of this ListAuthorizedDatabasesResponse.

        数据库及相关权限。

        :return: The databases of this ListAuthorizedDatabasesResponse.
        :rtype: list[:class:`huaweicloudsdkrds.v3.DatabaseWithPrivilege`]
        """
        return self._databases

    @databases.setter
    def databases(self, databases):
        r"""Sets the databases of this ListAuthorizedDatabasesResponse.

        数据库及相关权限。

        :param databases: The databases of this ListAuthorizedDatabasesResponse.
        :type databases: list[:class:`huaweicloudsdkrds.v3.DatabaseWithPrivilege`]
        """
        self._databases = databases

    @property
    def total_count(self):
        r"""Gets the total_count of this ListAuthorizedDatabasesResponse.

        总数。

        :return: The total_count of this ListAuthorizedDatabasesResponse.
        :rtype: int
        """
        return self._total_count

    @total_count.setter
    def total_count(self, total_count):
        r"""Sets the total_count of this ListAuthorizedDatabasesResponse.

        总数。

        :param total_count: The total_count of this ListAuthorizedDatabasesResponse.
        :type total_count: int
        """
        self._total_count = total_count

    def to_dict(self):
        import warnings
        warnings.warn("ListAuthorizedDatabasesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListAuthorizedDatabasesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
