# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListHistoryTopSqlsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total_count': 'int',
        'top_sqls': 'list[TopSql]'
    }

    attribute_map = {
        'total_count': 'total_count',
        'top_sqls': 'top_sqls'
    }

    def __init__(self, total_count=None, top_sqls=None):
        r"""ListHistoryTopSqlsResponse

        The model defined in huaweicloud sdk

        :param total_count: 总记录数
        :type total_count: int
        :param top_sqls: top sql 列表
        :type top_sqls: list[:class:`huaweicloudsdkrds.v3.TopSql`]
        """
        
        super().__init__()

        self._total_count = None
        self._top_sqls = None
        self.discriminator = None

        if total_count is not None:
            self.total_count = total_count
        if top_sqls is not None:
            self.top_sqls = top_sqls

    @property
    def total_count(self):
        r"""Gets the total_count of this ListHistoryTopSqlsResponse.

        总记录数

        :return: The total_count of this ListHistoryTopSqlsResponse.
        :rtype: int
        """
        return self._total_count

    @total_count.setter
    def total_count(self, total_count):
        r"""Sets the total_count of this ListHistoryTopSqlsResponse.

        总记录数

        :param total_count: The total_count of this ListHistoryTopSqlsResponse.
        :type total_count: int
        """
        self._total_count = total_count

    @property
    def top_sqls(self):
        r"""Gets the top_sqls of this ListHistoryTopSqlsResponse.

        top sql 列表

        :return: The top_sqls of this ListHistoryTopSqlsResponse.
        :rtype: list[:class:`huaweicloudsdkrds.v3.TopSql`]
        """
        return self._top_sqls

    @top_sqls.setter
    def top_sqls(self, top_sqls):
        r"""Sets the top_sqls of this ListHistoryTopSqlsResponse.

        top sql 列表

        :param top_sqls: The top_sqls of this ListHistoryTopSqlsResponse.
        :type top_sqls: list[:class:`huaweicloudsdkrds.v3.TopSql`]
        """
        self._top_sqls = top_sqls

    def to_dict(self):
        import warnings
        warnings.warn("ListHistoryTopSqlsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListHistoryTopSqlsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
