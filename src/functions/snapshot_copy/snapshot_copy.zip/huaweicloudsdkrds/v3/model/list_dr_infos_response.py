# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListDrInfosResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total_count': 'int',
        'instance_dr_infos': 'list[InstanceDrInfo]'
    }

    attribute_map = {
        'total_count': 'total_count',
        'instance_dr_infos': 'instance_dr_infos'
    }

    def __init__(self, total_count=None, instance_dr_infos=None):
        r"""ListDrInfosResponse

        The model defined in huaweicloud sdk

        :param total_count: 总记录数
        :type total_count: int
        :param instance_dr_infos: 实例容灾信息
        :type instance_dr_infos: list[:class:`huaweicloudsdkrds.v3.InstanceDrInfo`]
        """
        
        super().__init__()

        self._total_count = None
        self._instance_dr_infos = None
        self.discriminator = None

        if total_count is not None:
            self.total_count = total_count
        if instance_dr_infos is not None:
            self.instance_dr_infos = instance_dr_infos

    @property
    def total_count(self):
        r"""Gets the total_count of this ListDrInfosResponse.

        总记录数

        :return: The total_count of this ListDrInfosResponse.
        :rtype: int
        """
        return self._total_count

    @total_count.setter
    def total_count(self, total_count):
        r"""Sets the total_count of this ListDrInfosResponse.

        总记录数

        :param total_count: The total_count of this ListDrInfosResponse.
        :type total_count: int
        """
        self._total_count = total_count

    @property
    def instance_dr_infos(self):
        r"""Gets the instance_dr_infos of this ListDrInfosResponse.

        实例容灾信息

        :return: The instance_dr_infos of this ListDrInfosResponse.
        :rtype: list[:class:`huaweicloudsdkrds.v3.InstanceDrInfo`]
        """
        return self._instance_dr_infos

    @instance_dr_infos.setter
    def instance_dr_infos(self, instance_dr_infos):
        r"""Sets the instance_dr_infos of this ListDrInfosResponse.

        实例容灾信息

        :param instance_dr_infos: The instance_dr_infos of this ListDrInfosResponse.
        :type instance_dr_infos: list[:class:`huaweicloudsdkrds.v3.InstanceDrInfo`]
        """
        self._instance_dr_infos = instance_dr_infos

    def to_dict(self):
        import warnings
        warnings.warn("ListDrInfosResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListDrInfosResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
