# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListDbAgentJobHistorysResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'histories': 'list[ListDbAgentJobHistorysResult]',
        'total_count': 'int'
    }

    attribute_map = {
        'histories': 'histories',
        'total_count': 'total_count'
    }

    def __init__(self, histories=None, total_count=None):
        r"""ListDbAgentJobHistorysResponse

        The model defined in huaweicloud sdk

        :param histories: 执行历史列表。
        :type histories: list[:class:`huaweicloudsdkrds.v3.ListDbAgentJobHistorysResult`]
        :param total_count: 执行历史总数。
        :type total_count: int
        """
        
        super().__init__()

        self._histories = None
        self._total_count = None
        self.discriminator = None

        if histories is not None:
            self.histories = histories
        if total_count is not None:
            self.total_count = total_count

    @property
    def histories(self):
        r"""Gets the histories of this ListDbAgentJobHistorysResponse.

        执行历史列表。

        :return: The histories of this ListDbAgentJobHistorysResponse.
        :rtype: list[:class:`huaweicloudsdkrds.v3.ListDbAgentJobHistorysResult`]
        """
        return self._histories

    @histories.setter
    def histories(self, histories):
        r"""Sets the histories of this ListDbAgentJobHistorysResponse.

        执行历史列表。

        :param histories: The histories of this ListDbAgentJobHistorysResponse.
        :type histories: list[:class:`huaweicloudsdkrds.v3.ListDbAgentJobHistorysResult`]
        """
        self._histories = histories

    @property
    def total_count(self):
        r"""Gets the total_count of this ListDbAgentJobHistorysResponse.

        执行历史总数。

        :return: The total_count of this ListDbAgentJobHistorysResponse.
        :rtype: int
        """
        return self._total_count

    @total_count.setter
    def total_count(self, total_count):
        r"""Sets the total_count of this ListDbAgentJobHistorysResponse.

        执行历史总数。

        :param total_count: The total_count of this ListDbAgentJobHistorysResponse.
        :type total_count: int
        """
        self._total_count = total_count

    def to_dict(self):
        import warnings
        warnings.warn("ListDbAgentJobHistorysResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListDbAgentJobHistorysResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
