# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListHistorySessionsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total_count': 'int',
        'sessions': 'list[Session]'
    }

    attribute_map = {
        'total_count': 'total_count',
        'sessions': 'sessions'
    }

    def __init__(self, total_count=None, sessions=None):
        r"""ListHistorySessionsResponse

        The model defined in huaweicloud sdk

        :param total_count: 总记录数
        :type total_count: int
        :param sessions: 会话信息列表
        :type sessions: list[:class:`huaweicloudsdkrds.v3.Session`]
        """
        
        super().__init__()

        self._total_count = None
        self._sessions = None
        self.discriminator = None

        if total_count is not None:
            self.total_count = total_count
        if sessions is not None:
            self.sessions = sessions

    @property
    def total_count(self):
        r"""Gets the total_count of this ListHistorySessionsResponse.

        总记录数

        :return: The total_count of this ListHistorySessionsResponse.
        :rtype: int
        """
        return self._total_count

    @total_count.setter
    def total_count(self, total_count):
        r"""Sets the total_count of this ListHistorySessionsResponse.

        总记录数

        :param total_count: The total_count of this ListHistorySessionsResponse.
        :type total_count: int
        """
        self._total_count = total_count

    @property
    def sessions(self):
        r"""Gets the sessions of this ListHistorySessionsResponse.

        会话信息列表

        :return: The sessions of this ListHistorySessionsResponse.
        :rtype: list[:class:`huaweicloudsdkrds.v3.Session`]
        """
        return self._sessions

    @sessions.setter
    def sessions(self, sessions):
        r"""Sets the sessions of this ListHistorySessionsResponse.

        会话信息列表

        :param sessions: The sessions of this ListHistorySessionsResponse.
        :type sessions: list[:class:`huaweicloudsdkrds.v3.Session`]
        """
        self._sessions = sessions

    def to_dict(self):
        import warnings
        warnings.warn("ListHistorySessionsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListHistorySessionsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
